package shoppingart.dao;

import shoppingcart.entity.product;
import shoppingcart.model.java.productinfo;
import shoppingcart.model.java.result;

public interface productdao {
 
    
    
    public product findProduct(String code);
    
    public productinfo<?> findproductinfo(String code) ;
  
    
    public result<productinfo> queryProducts(int page,
                       int maxResult, int maxNavigationPage  );
    
    public result<productinfo> queryProducts(int page, int maxResult,
                       int maxNavigationPage, String likeName);
 
    public void save(productinfo<?> productinfo);
    
}
