package shoppingart.dao;

import shoppingcart.entity.account;

public interface accdao {
 
    
    public account findAccount(String userName );
    
}
