package shoppingcart.validator;

import shoppingcart.model.java.customerinfo;

public class customerinfovalidator implements validator {
 
    private EmailValidator emailValidator = EmailValidator.getInstance();
 
  public boolean supports(Class<?> clazz) {
        return clazz == customerinfo.class;
    }
 
    @Override
    public void validate(Object target, Errors errors) {
        customerinfo custInfo = (customerinfo) target;
 

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "NotEmpty.customerForm.name");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "NotEmpty.customerForm.email");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "NotEmpty.customerForm.address");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone", "NotEmpty.customerForm.phone");
 
        if (!emailValidator.isValid(custInfo.getEmail())) {
            errors.rejectValue("email", "Pattern.customerForm.email");
        }
    }
 
}