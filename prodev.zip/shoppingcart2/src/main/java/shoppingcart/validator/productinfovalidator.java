package shoppingcart.validator;

import shoppingcart.entity.product;
import shoppingcart.model.java.productinfo;

public class productinfovalidator implements validator {
 
    @Autowired
    private shoppingart.dao.productdao productdao;
 
   
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz == productinfo.class;
    }
 
    @Override
    public void validate(Object target, Errors errors) {
        productinfo productinfo = (productinfo) target;
 
     
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "code", "NotEmpty.productForm.code");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "NotEmpty.productForm.name");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "price", "NotEmpty.productForm.price");
 
        String code = productinfo.getCode();
        if (code != null && code.length() > 0) {
            if (code.matches("\\s+")) {
                errors.rejectValue("code", "Pattern.productForm.code");
            } else if(productinfo.isNewProduct()) {
                product product = productdao.findProduct(code);
                if (product != null) {
                    errors.rejectValue("code", "Duplicate.productForm.code");
                }
            }
        }
    }
 
}
