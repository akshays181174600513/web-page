package shoppingcart.config;

public class webmvcconfig {

}
