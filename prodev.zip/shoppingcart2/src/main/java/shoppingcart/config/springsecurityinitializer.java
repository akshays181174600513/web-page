package shoppingcart.config;

public class springsecurityinitializer {

}
