package shoppingcart.config;

public interface WebApplicationInitializer {

}
