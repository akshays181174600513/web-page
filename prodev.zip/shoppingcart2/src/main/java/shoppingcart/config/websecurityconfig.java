package shoppingcart.config;

public class websecurityconfig {

}
