package shoppingcart.config;

public class springwebappinitializer {

}
