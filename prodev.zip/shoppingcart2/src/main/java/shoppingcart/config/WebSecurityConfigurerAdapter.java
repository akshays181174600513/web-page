package shoppingcart.config;

public class WebSecurityConfigurerAdapter {

}
