package shoppingcart.config;

public class AbstractSecurityWebApplicationInitializer {

}
