package shoppingcart.config;

public class appcontextconfig {

}
