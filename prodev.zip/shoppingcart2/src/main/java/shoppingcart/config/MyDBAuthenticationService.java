package shoppingcart.config;

public class MyDBAuthenticationService {

}
