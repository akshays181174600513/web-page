package shoppingcart.dao.impl.java;

import shoppingart.dao.accdao;
import shoppingcart.entity.account;

public class accountdaoimpl  implements accdao {
    
    @Autowired
    private SessionFactory sessionFactory;
 
    public account findAccount(String userName ) {
        Session session = sessionFactory.getCurrentSession();
        Criteria crit = session.createCriteria(account.class);
        crit.add(Restrictions.eq("userName", userName));
        return (account) crit.uniqueResult();
    }
 
}