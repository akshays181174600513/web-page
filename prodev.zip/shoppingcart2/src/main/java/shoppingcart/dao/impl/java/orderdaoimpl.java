package shoppingcart.dao.impl.java;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import shoppingart.dao.orderdao;
import shoppingcart.entity.order;
import shoppingcart.entity.orderdetail;
import shoppingcart.entity.product;
import shoppingcart.model.java.cartinfo;
import shoppingcart.model.java.cartlineinfo;
import shoppingcart.model.java.customerinfo;
import shoppingcart.model.java.orderdetailinfo;
import shoppingcart.model.java.result;

public class orderdaoimpl<orderinfo> implements orderdao {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    @Autowired
    private shoppingart.dao.productdao productdao;
 
    private int getMaxOrderNum() {
        String sql = "Select max(o.orderNum) from " + order.class.getName() + " o ";
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery(sql);
        Integer value = (Integer) query.uniqueResult();
        if (value == null) {
            return 0;
        }
        return value;
    }
 
    @Override
    public void saveOrder(cartinfo cartInfo) {
        Session session = sessionFactory.getCurrentSession();
 
        int orderNum = this.getMaxOrderNum() + 1;
        order order = new order();
 
        order.setId(UUID.randomUUID().toString());
        order.setOrderNum(orderNum);
        order.setOrderDate(new Date());
        order.setAmount(cartInfo.getAmountTotal());
 
        customerinfo customerInfo = cartInfo.getCustomerInfo();
        order.setCustomerName(customerInfo.getName());
        order.setCustomerEmail(customerInfo.getEmail());
        order.setCustomerPhone(customerInfo.getPhone());
        order.setCustomerAddress(customerInfo.getAddress());
 
        session.persist(order);
 
        List<cartlineinfo> lines = cartInfo.getCartLines();
 
        for (cartlineinfo line : lines) {
            orderdetail detail = new orderdetail();
            detail.setId(UUID.randomUUID().toString());
            detail.setOrder(order);
            detail.setAmount(line.getAmount());
            detail.setPrice(line.getProductInfo().getPrice());
            detail.setQuanity(line.getQuantity());
 
            String code = line.getProductInfo().getCode();
            product product = this.productdao.findProduct(code);
            detail.setProduct(product);
 
            session.persist(detail);
        }
 
       
        cartInfo.setOrderNum(orderNum);
    }
 
   
    @Override
    public result<orderinfo> Listorderinfo(int page, int maxResult, int maxNavigationPage) {
        String sql = "Select new " + orderinfo.class.getName()//
                + "(ord.id, ord.orderDate, ord.orderNum, ord.amount, "
                + " ord.customerName, ord.customerAddress, ord.customerEmail, ord.customerPhone) " + " from "
                + Order.class.getName() + " ord "//
                + " order by ord.orderNum desc";
        Session session = this.sessionFactory.getCurrentSession();
 
        Query query = session.createQuery(sql);
 
        return new result<orderinfo>(query, page, maxResult, maxNavigationPage);
    }
 
    public order findOrder(String orderId) {
        Session session = sessionFactory.getCurrentSession();
        Criteria crit = session.createCriteria(order.class);
        crit.add(Restrictions.eq("id", orderId));
        return (order) crit.uniqueResult();
    }
 
    @Override
    public orderinfo Getorderinfo(String orderId) {
        order order = this.findOrder(orderId);
        if (order == null) {
            return null;
        }
        return new orderinfo(order.getId(), order.getOrderDate(), //
                order.getOrderNum(), order.getAmount(), order.getCustomerName(), //
                order.getCustomerAddress(), order.getCustomerEmail(), order.getCustomerPhone());
    }
 
    public List<orderdetailinfo> listorderdetailinfo(String orderId) {
        String sql = "Select new " + OrderDetailInfo.class.getName() //
                + "(d.id, d.product.code, d.product.name , d.quanity,d.price,d.amount) "//
                + " from " + OrderDetail.class.getName() + " d "//
                + " where d.order.id = :orderId ";
 
        Session session = this.sessionFactory.getCurrentSession();
 
        Query query = session.createQuery(sql);
        query.setParameter("orderId", orderId);
 
        return query.list();
    }
 
}

