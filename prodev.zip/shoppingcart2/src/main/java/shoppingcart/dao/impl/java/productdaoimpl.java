package shoppingcart.dao.impl.java;

import java.util.Date;

import shoppingart.dao.productdao;
import shoppingcart.entity.product;
import shoppingcart.model.java.productinfo;
import shoppingcart.model.java.result;

public class productdaoimpl implements productdao {
 
    @Autowired
    private SessionFactory sessionFactory;
 
    public product findproduct(String code) {
        Session session = sessionFactory.getCurrentSession();
        Criteria crit = session.createCriteria(product.class);
        crit.add(Restrictions.eq("code", code));
        return (product) crit.uniqueResult();
    }
 
    public productinfo findproductinfo(String code) {
        product product = this.findproduct(code);
        if (product == null) {
            return null;
        }
        return new productinfo(product.getCode(), product.getName(), product.getPrice());
    }
 
    public void save(productinfo productinfo) {
        String code = productinfo.getCode();
 
        product product = null;
 
        boolean isNew = false;
        if (code != null) {
            product = this.findProduct(code);
        }
        if (product == null) {
            isNew = true;
            product = new product();
            product.setCreateDate(new Date());
        }
        product.setCode(code);
        product.setName(productinfo.getName());
        product.setPrice(productinfo.getPrice());
 
        if (productinfo.getFileData() != null) {
            byte[] image = ((String) productinfo.getFileData()).getBytes();
            if (image != null && image.length > 0) {
                product.setImage(image);
            }
        }
        if (isNew) {
            this.sessionFactory.getCurrentSession().persist(product);
        }
        
        this.sessionFactory.getCurrentSession().flush();
    }
 
    public result<productinfo> queryproduct(int page, int maxResult, int maxNavigationPage,
            String likeName) {
        String sql = "Select new " + productinfo.class.getName() //
                + "(p.code, p.name, p.price) " + " from "//
                + product.class.getName() + " p ";
        if (likeName != null && likeName.length() > 0) {
            sql += " Where lower(p.name) like :likeName ";
        }
        sql += " order by p.createDate desc ";
        //
        Session session = sessionFactory.getCurrentSession();
 
        Query query = session.createQuery(sql);
        if (likeName != null && likeName.length() > 0) {
            query.setParameter("likeName", "%" + likeName.toLowerCase() + "%");
        }
        return new result<productinfo>(query, page, maxResult, maxNavigationPage);
    }
 
    public result<productinfo> queryproduct(int page, int maxResult, int maxNavigationPage) {
        return queryProducts(page, maxResult, maxNavigationPage, null);
    }

	public product findProduct(String code) {
		
		return null;
	}

	public productinfo<?> findproductinf(String code) {
		
		return null;
	}

	public result<productinfo> queryProducts(int page, int maxResult, int maxNavigationPage) {
		
		return null;
	}

	public result<productinfo> queryProducts(int page, int maxResult, int maxNavigationPage, String likeName) {
		
		return null;
	}

	public void sav(productinfo<?> productinfo) {
		
		
	}
    
}