package shoppingcart.controller;

import shoppingcart.model.java.orderinfo;
import shoppingcart.model.java.productinfo;
import shoppingcart.model.java.result;

public class maincontroller  {
 
    @Autowired
    private shoppingart.dao.orderdao orderdao;
 
    @Autowired
    private shoppingart.dao.productdao productdao;
 
    @Autowired
    private productinfo productinfovalidator;
 
 
    @Autowired
    private ResourceBundleMessageSource messageSource;
 
    @InitBinder
    public void myInitBinder(WebDataBinder dataBinder) {
        Object target = dataBinder.getTarget();
        if (target == null) {
            return;
        }
        System.out.println("Target=" + target);
 
        if (target.getClass() == productinfo.class) {
            dataBinder.setValidator(productinfovalidator);
           
            dataBinder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());
        }
    }
 
    
    @RequestMapping(value = { "/login" }, method = RequestMethod.GET)
    public String login(Model model) {
 
        return "login";
    }
 
    @RequestMapping(value = { "/accountInfo" }, method = RequestMethod.GET)
    public String accountInfo(Model model) {
 
        userdetail userdetail = (userdetail) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        System.out.println(userdetail.getPassword());
        System.out.println(userdetail.getUsername());
        System.out.println(userdetail.isEnabled());
 
        model.addAttribute("useretail", userdetail);
        return "accountInfo";
    }
 
    @RequestMapping(value = { "/orderlist" }, method = RequestMethod.GET)
    public String orderList(Model model, //
            @RequestParam(value = "page", defaultValue = "1") String pageStr) {
        int page = 1;
        try {
            page = Integer.parseInt(pageStr);
        } catch (Exception e) {
        }
        final int MAX_RESULT = 5;
        final int MAX_NAVIGATION_PAGE = 10;
 
      result<orderinfo> result //
        = orderdao.listorderinfo(page);
 
        model.addAttribute("result", result);
        return "orderList";
    }
 

    @RequestMapping(value = { "/product" }, method = RequestMethod.GET)
    public String product(Model model, @RequestParam(value = "code", defaultValue = "") String code) {
        productinfo productinfo = null;
 
        if (code != null && code.length() > 0) {
            productinfo = productdao.findProduct(code);
        }
        if (productinfo == null) {
            productinfo = new productinfo();
            productinfo.setNewproduct(true);
        }
        model.addAttribute("productForm", productInfo);
        return "product";
    }
 
    
    @RequestMapping(value = { "/product" }, method = RequestMethod.POST)

    @Transactional(propagation = Propagation.NEVER)
    public String productSave(Model model, //
            @ModelAttribute("productForm") @Validated ProductInfo productInfo, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
 
        if (result.hasErrors()) {
            return "product";
        }
        try {
            productdao.save(productInfo);
        } catch (Exception e) {

            String message = e.getMessage();
            model.addAttribute("message", message);
          
            return "product";
 
        }
        return "redirect:/productList";
    }
 
    @RequestMapping(value = { "/order" }, method = RequestMethod.GET)
    public String orderView(Model model, @RequestParam("orderId") String orderId) {
        orderinfo orderInfo = null;
        if (orderId != null) {
            orderInfo = this.orderdao.getOrderInfo(orderId);
        }
        if (orderInfo == null) {
            return "redirect:/orderList";
        }
        List<orderdetailinfo> details = this.orderdao.listorderdetailinfo(orderId);
        orderInfo.setDetails(details);
 
        model.addAttribute("orderInfo", orderInfo);
 
        return "order";
    }
    
}
