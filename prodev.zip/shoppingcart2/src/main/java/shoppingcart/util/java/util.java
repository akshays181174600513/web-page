package shoppingcart.util.java;
import javax.servlet.http.HttpServletRequest;

import shoppingcart.model.java.cartinfo;
public class util {
 
    
    public static <HttpServletRequest> cartinfo getCartInSession(HttpServletRequest request) {
 
    
        cartinfo cartinfo = (cartinfo) ((Object) request).getSession().getAttribute("myCart");
        
    
        if (cartinfo == null) {
            cartinfo = new cartinfo();
            
           
            request.getSession().setAttribute("myCart", cartinfo);
        }
 
        return cartinfo;
    }
 
    public static void removeCartInSession(HttpServletRequest request) {
        request.getSession().removeAttribute("myCart");
    }
 
    public static void storeLastOrderedCartInSession(HttpServletRequest request, cartinfo cartinfo) {
        request.getSession().setAttribute("lastOrderedCart", cartinfo);
    }
    
    public static cartinfo getLastOrderedCartInSession(HttpServletRequest request) {
        return (cartinfo) request.getSession().getAttribute("lastOrderedCart");
    }
 
}